const router = require('express').Router();

const agronomi = require('../businessintelligence/Agronomi')

router.use('/agronomi', agronomi)



module.exports = router;

