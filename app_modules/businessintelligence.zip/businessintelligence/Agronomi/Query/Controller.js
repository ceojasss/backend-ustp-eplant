const dbagro = require("./DBHandler");
const router = require("express").Router();
const { sendResult } = require('../../../../util/HelperUtility')




async function get(req, res, next) {
  await dbagro.fetchDatas((error, result) => {
      if (error) {
          return next(error)
      }
      sendResult(result, res)

  })
}


module.exports = {get}
  
