const _ = require("lodash");
const mysql = require("mysql");
// const baseQuery = `SELECT * FROM mytable`;
// const database = require('../../../../oradb/dbHandler')
// const database = require('../../../../oradb/dbHandler')
// const {pool} = require('../config')
const dbCredentials = require('../../../../oradb/dbCredentials');
const site = _.find(dbCredentials, ['poolAlias', process.argv[2]])
console.log(site)



const fetchDatas = async  () =>{
  return new Promise(async ( resolve, reject) => {
    let dbConnection;
    let result
  // console.log(route)

   // Creating pool connection ysql
   var pool  = await mysql.createPool({
    connectionLimit : 100,
    host     : '127.0.0.1',
    user     : 'root',
    password : '',
    database : 'dbmapindo',
    debug    :  false

    
  });

    try {
      
      pool.getConnection( function(err, conn){
        conn.query("select * from mytable where city = 'Amahai' ", function(err, rows) {
          if(err) {
            console.log(err)
          }
          // return rows
          // console.log(JSON.stringify(rows))

          const result = JSON.stringify(rows)
          console.log(result)

          resolve({data : result.rows})
          
          // console.log('resolve' , resolve())

        })

    })
  } catch (error) {
    console.log("error get data")
    reject(error)
  }
  })





  
}


module.exports = {
  fetchDatas
};