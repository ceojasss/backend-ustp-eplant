const router = require("express").Router();

const query = require("./Query/Controller");

router.route(`/query`)
    .get(query.get);

module.exports = router;